const express = require('express');
const { readJSON, writeJSON } = require('../fileStore');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

const FNAME = 'menu.json';

// GET all menu items
router.get('/', async (req, res) => {
  const items = await readJSON(FNAME, []);
  res.json(items);
});

// GET single menu item
router.get('/:id', async (req, res) => {
  const items = await readJSON(FNAME, []);
  const item = items.find(i => i.id === req.params.id);
  if (!item) return res.status(404).json({ message: 'Not found' });
  res.json(item);
});

// CREATE menu item
router.post('/', async (req, res) => {
  const { name, description = '', price = 0, available = true } = req.body;
  if (!name) return res.status(400).json({ message: 'Name required' });

  const items = await readJSON(FNAME, []);
  const newItem = {
    id: uuidv4(),
    name,
    description,
    price: Number(price) || 0,
    available: !!available,
    createdAt: new Date().toISOString()
  };
  items.push(newItem);
  await writeJSON(FNAME, items);
  res.status(201).json(newItem);
});

// UPDATE menu item
router.put('/:id', async (req, res) => {
  const items = await readJSON(FNAME, []);
  const idx = items.findIndex(i => i.id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Not found' });
  const updated = { ...items[idx], ...req.body, price: Number(req.body.price ?? items[idx].price) };
  items[idx] = updated;
  await writeJSON(FNAME, items);
  res.json(updated);
});

// DELETE menu item
router.delete('/:id', async (req, res) => {
  const items = await readJSON(FNAME, []);
  const filtered = items.filter(i => i.id !== req.params.id);
  if (filtered.length === items.length) return res.status(404).json({ message: 'Not found' });
  await writeJSON(FNAME, filtered);
  res.json({ message: 'Deleted' });
});

module.exports = router;
