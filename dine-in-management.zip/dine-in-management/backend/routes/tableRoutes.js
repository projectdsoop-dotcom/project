const express = require('express');
const { readJSON, writeJSON } = require('../fileStore');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

const FNAME = 'tables.json';

// GET tables
router.get('/', async (req, res) => {
  const list = await readJSON(FNAME, []);
  res.json(list);
});

// CREATE table
router.post('/', async (req, res) => {
  const { number, seats = 4, status = 'available' } = req.body;
  if (!number) return res.status(400).json({ message: 'Table number required' });
  const list = await readJSON(FNAME, []);
  const exists = list.find(t => t.number === number);
  if (exists) return res.status(400).json({ message: 'Table number exists' });
  const newTable = {
    id: uuidv4(),
    number,
    seats: Number(seats) || 4,
    status,
    createdAt: new Date().toISOString()
  };
  list.push(newTable);
  await writeJSON(FNAME, list);
  res.status(201).json(newTable);
});

// UPDATE table
router.put('/:id', async (req, res) => {
  const list = await readJSON(FNAME, []);
  const idx = list.findIndex(t => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Not found' });
  list[idx] = { ...list[idx], ...req.body, seats: Number(req.body.seats ?? list[idx].seats) };
  await writeJSON(FNAME, list);
  res.json(list[idx]);
});

// DELETE table
router.delete('/:id', async (req, res) => {
  const list = await readJSON(FNAME, []);
  const newList = list.filter(t => t.id !== req.params.id);
  if (newList.length === list.length) return res.status(404).json({ message: 'Not found' });
  await writeJSON(FNAME, newList);
  res.json({ message: 'Deleted' });
});

module.exports = router;
