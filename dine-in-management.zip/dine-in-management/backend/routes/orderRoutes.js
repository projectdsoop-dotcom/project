const express = require('express');
const { readJSON, writeJSON } = require('../fileStore');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

const ORDERS = 'orders.json';
const MENU = 'menu.json';
const TABLES = 'tables.json';

/**
 * Order structure:
 * {
 *   id,
 *   tableId,
 *   items: [{ menuId, name, price, qty }],
 *   status: 'pending'|'preparing'|'served'|'paid',
 *   total,
 *   createdAt
 * }
 */

// GET all orders
router.get('/', async (req, res) => {
  const list = await readJSON(ORDERS, []);
  res.json(list);
});

// GET single order
router.get('/:id', async (req, res) => {
  const list = await readJSON(ORDERS, []);
  const order = list.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ message: 'Not found' });
  res.json(order);
});

// CREATE order
router.post('/', async (req, res) => {
  const { tableId, items } = req.body;
  if (!tableId) return res.status(400).json({ message: 'tableId required' });
  if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ message: 'items required' });

  // read menu & tables to validate
  const menu = await readJSON(MENU, []);
  const tables = await readJSON(TABLES, []);

  const table = tables.find(t => t.id === tableId);
  if (!table) return res.status(400).json({ message: 'Invalid tableId' });

  // build items with price & name snapshot
  let total = 0;
  const prepared = items.map(it => {
    const menuItem = menu.find(m => m.id === it.menuId);
    const name = menuItem ? menuItem.name : (it.name || 'Unknown');
    const price = menuItem ? Number(menuItem.price || 0) : Number(it.price || 0);
    const qty = Number(it.qty || 1);
    total += price * qty;
    return { menuId: it.menuId, name, price, qty };
  });

  const newOrder = {
    id: uuidv4(),
    tableId,
    items: prepared,
    status: 'pending',
    total: Number(total.toFixed(2)),
    createdAt: new Date().toISOString()
  };

  const orders = await readJSON(ORDERS, []);
  orders.push(newOrder);
  await writeJSON(ORDERS, orders);

  // Optionally mark table as occupied
  const updatedTables = tables.map(t => t.id === tableId ? { ...t, status: 'occupied' } : t);
  await writeJSON(TABLES, updatedTables);

  res.status(201).json(newOrder);
});

// UPDATE order (e.g., status)
router.put('/:id', async (req, res) => {
  const orders = await readJSON(ORDERS, []);
  const idx = orders.findIndex(o => o.id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Not found' });

  // If status changed to 'paid', free table
  const prev = orders[idx];
  const updated = { ...prev, ...req.body };

  // recalc total if items changed
  if (req.body.items) {
    updated.total = req.body.items.reduce((s, it) => s + (Number(it.price || 0) * Number(it.qty || 1)), 0);
  }

  orders[idx] = updated;
  await writeJSON(ORDERS, orders);

  // If paid -> free table
  if (updated.status === 'paid') {
    const tables = await readJSON(TABLES, []);
    const changed = tables.map(t => t.id === updated.tableId ? { ...t, status: 'available' } : t);
    await writeJSON(TABLES, changed);
  }

  res.json(updated);
});

// DELETE order
router.delete('/:id', async (req, res) => {
  const orders = await readJSON(ORDERS, []);
  const newOrders = orders.filter(o => o.id !== req.params.id);
  if (newOrders.length === orders.length) return res.status(404).json({ message: 'Not found' });
  await writeJSON(ORDERS, newOrders);
  res.json({ message: 'Deleted' });
});

module.exports = router;
