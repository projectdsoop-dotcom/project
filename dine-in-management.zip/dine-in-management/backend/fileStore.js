/**
 * fileStore.js
 * Lightweight JSON file read/write helper using fs-extra
 */
const fs = require('fs-extra');
const path = require('path');

const dataDir = path.join(__dirname, 'data');

async function ensureDataDir() {
  await fs.ensureDir(dataDir);
}

function filePath(filename) {
  return path.join(dataDir, filename);
}

async function readJSON(filename, defaultValue = []) {
  await ensureDataDir();
  const fp = filePath(filename);
  try {
    const exists = await fs.pathExists(fp);
    if (!exists) {
      await fs.writeJson(fp, defaultValue, { spaces: 2 });
      return defaultValue;
    }
    const data = await fs.readJson(fp);
    return data;
  } catch (err) {
    console.error('readJSON error', err);
    return defaultValue;
  }
}

async function writeJSON(filename, data) {
  await ensureDataDir();
  const fp = filePath(filename);
  await fs.writeJson(fp, data, { spaces: 2 });
}

module.exports = { readJSON, writeJSON, filePath, dataDir };
