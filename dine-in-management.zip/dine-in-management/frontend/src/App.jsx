import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Admin from './pages/Admin';
import Waiter from './pages/Waiter';

export default function App() {
  return (
    <div>
      <header className="topnav">
        <div className="brand">Dine-in Management</div>
        <nav>
          <Link to="/admin">Admin</Link>
          <Link to="/waiter">Waiter</Link>
        </nav>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={<Admin />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/waiter" element={<Waiter />} />
        </Routes>
      </main>
    </div>
  );
}
