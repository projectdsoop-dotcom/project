import React, { useEffect, useState } from 'react';
import api from '../api';

export default function Waiter() {
  const [menu, setMenu] = useState([]);
  const [tables, setTables] = useState([]);
  const [cart, setCart] = useState([]);
  const [selectedTable, setSelectedTable] = useState('');

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const [m, t] = await Promise.all([api.get('/menu'), api.get('/tables')]);
      setMenu(m.data);
      setTables(t.data);
    } catch (err) {
      console.error(err);
    }
  }

  function addToCart(item) {
    const existing = cart.find(c => c.menuId === item.id);
    if (existing) {
      setCart(cart.map(c => c.menuId === item.id ? { ...c, qty: c.qty + 1 } : c));
    } else {
      setCart([...cart, { menuId: item.id, name: item.name, price: item.price, qty: 1 }]);
    }
  }

  function removeFromCart(menuId) {
    setCart(cart.filter(c => c.menuId !== menuId));
  }

  async function placeOrder() {
    if (!selectedTable) return alert('Select table');
    if (cart.length === 0) return alert('Cart empty');
    await api.post('/orders', { tableId: selectedTable, items: cart });
    setCart([]);
    setSelectedTable('');
    load();
    alert('Order placed');
  }

  return (
    <div>
      <h2>Waiter Panel</h2>
      <div className="flex">
        <div style={{ flex: 1 }}>
          <h3>Menu</h3>
          {menu.map(it => (
            <div className="row" key={it.id}>
              <div>{it.name} — ₹{Number(it.price).toFixed(2)}</div>
              <div><button onClick={()=>addToCart(it)}>+ Add</button></div>
            </div>
          ))}
        </div>

        <div style={{ width: 360 }}>
          <h3>Cart</h3>
          {cart.map(c => (
            <div className="row" key={c.menuId}>
              <div>{c.name} x {c.qty}</div>
              <div><button onClick={()=>removeFromCart(c.menuId)}>Remove</button></div>
            </div>
          ))}

          <select value={selectedTable} onChange={e => setSelectedTable(e.target.value)}>
            <option value="">Select table</option>
            {tables.map(t => <option value={t.id} key={t.id}>{t.number} ({t.seats})</option>)}
          </select>

          <div style={{ marginTop: 8 }}>
            <button onClick={placeOrder}>Place Order</button>
          </div>
        </div>
      </div>
    </div>
  );
}
