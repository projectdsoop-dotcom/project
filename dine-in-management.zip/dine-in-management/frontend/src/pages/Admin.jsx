import React, { useEffect, useState } from 'react';
import api from '../api';

export default function Admin() {
  const [menu, setMenu] = useState([]);
  const [tables, setTables] = useState([]);
  const [orders, setOrders] = useState([]);

  // menu form
  const [mname, setMname] = useState('');
  const [mprice, setMprice] = useState('');

  // table form
  const [tNumber, setTNumber] = useState('');
  const [tSeats, setTSeats] = useState(4);

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    try {
      const [mRes, tRes, oRes] = await Promise.all([
        api.get('/menu'),
        api.get('/tables'),
        api.get('/orders')
      ]);
      setMenu(mRes.data);
      setTables(tRes.data);
      setOrders(oRes.data);
    } catch (err) {
      console.error(err);
      alert('Failed to load data');
    }
  }

  async function addMenu() {
    if (!mname) return alert('Name required');
    await api.post('/menu', { name: mname, price: Number(mprice || 0) });
    setMname(''); setMprice('');
    loadAll();
  }

  async function deleteMenu(id) {
    if (!confirm('Delete item?')) return;
    await api.delete(`/menu/${id}`);
    loadAll();
  }

  async function addTable() {
    if (!tNumber) return alert('Table number required');
    await api.post('/tables', { number: tNumber, seats: Number(tSeats) });
    setTNumber(''); setTSeats(4);
    loadAll();
  }

  async function deleteTable(id) {
    if (!confirm('Delete table?')) return;
    await api.delete(`/tables/${id}`);
    loadAll();
  }

  async function setOrderStatus(id, status) {
    await api.put(`/orders/${id}`, { status });
    loadAll();
  }

  return (
    <div>
      <h2>Admin Dashboard</h2>

      <section className="card">
        <h3>Menu</h3>
        <div className="form-row">
          <input placeholder="Name" value={mname} onChange={e=>setMname(e.target.value)} />
          <input placeholder="Price" type="number" value={mprice} onChange={e=>setMprice(e.target.value)} />
          <button onClick={addMenu}>Add Menu</button>
        </div>
        <div>
          {menu.map(item => (
            <div className="row" key={item.id}>
              <div>{item.name} — ₹{Number(item.price).toFixed(2)}</div>
              <div><button onClick={()=>deleteMenu(item.id)}>Delete</button></div>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <h3>Tables</h3>
        <div className="form-row">
          <input placeholder="Table No." value={tNumber} onChange={e=>setTNumber(e.target.value)} />
          <input placeholder="Seats" type="number" value={tSeats} onChange={e=>setTSeats(e.target.value)} />
          <button onClick={addTable}>Add Table</button>
        </div>
        <div>
          {tables.map(t => (
            <div className="row" key={t.id}>
              <div>#{t.number} — seats {t.seats} — {t.status}</div>
              <div><button onClick={()=>deleteTable(t.id)}>Delete</button></div>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <h3>Orders</h3>
        <div>
          {orders.map(o => (
            <div className="order-card" key={o.id}>
              <div><b>Order #{o.id}</b> — Table: {o.tableId} — Status: {o.status} — Total: ₹{o.total}</div>
              <div>
                <button onClick={()=>setOrderStatus(o.id, 'preparing')}>Preparing</button>
                <button onClick={()=>setOrderStatus(o.id, 'served')}>Served</button>
                <button onClick={()=>setOrderStatus(o.id, 'paid')}>Paid</button>
              </div>
              <div>
                {o.items.map(it => <div key={it.menuId}>{it.name} x {it.qty} — ₹{it.price}</div>)}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
